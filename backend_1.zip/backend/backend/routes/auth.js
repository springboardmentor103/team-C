// // routes/auth.js
// import express from "express";
// const router = express.Router();

// // Register route (placeholder)
// router.post("/register", (req, res) => {
//   // TODO: implement registration logic
//   res.json({ message: "Register route placeholder" });
// });

// // Verify OTP route (placeholder)
// router.post("/verify-otp", (req, res) => {
//   // TODO: implement OTP verification
//   res.json({ message: "OTP route placeholder" });
// });

// // Login route (placeholder)
// router.post("/login", (req, res) => {
//   // TODO: implement login logic
//   res.json({ message: "Login route placeholder" });
// });

// export default router;




// --------------------------------------------------------------------------------------------

import express from "express";
import {
  registerUser,
  verifyOtp,
  loginUser
} from "../controllers/authController.js";

const router = express.Router();

router.post("/register", registerUser);
router.post("/verify-otp", verifyOtp);
router.post("/login", loginUser);

export default router;

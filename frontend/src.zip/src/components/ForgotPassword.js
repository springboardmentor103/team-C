function ForgotPassword({ setPage }) {
  return (
    <div className="card">
      <h2>Forgot Password</h2>
      <p className="subtitle">We’ll send you a reset link</p>

      <label>Email Address</label>
      <input type="email" placeholder="Enter your email" />

      <button className="btn">Reset Password</button>

      <p className="switch">
        <span className="link" onClick={() => setPage("login")}>
          Back to Login
        </span>
      </p>
    </div>
  );
}

export default ForgotPassword;

// User model structure for HireHelper backend

const User = {
  name: String,
  email: String,
  password: String,
  otp: String,
  isVerified: Boolean,
  createdAt: Date
};

module.exports = User;
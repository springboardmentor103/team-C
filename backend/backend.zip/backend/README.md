# HireHelper Backend

This folder contains the backend structure for the HireHelper application.

## Milestone-1 Scope
- User Registration
- OTP Verification
- Login

## Folder Structure
- routes/       → API routes
- controllers/  → Request handling logic
- models/       → Data models

This structure is prepared for implementing authentication and OTP modules.